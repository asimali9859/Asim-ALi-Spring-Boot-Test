package com.dbms.shopping.service;

//Created by M Asim ALi
import java.util.List;

import com.dbms.shopping.entity.CustomerAccount;

public interface CustomerAccountService {
	boolean addCustomerAccount(CustomerAccount customerAccount);

	List<CustomerAccount> searchCustomerAccount(String username);

	int countCustomer();
}
