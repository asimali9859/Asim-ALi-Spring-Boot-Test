package com.dbms.shopping.dao;

import java.util.List;

import com.dbms.shopping.entity.Product;

//Created by M Asim ALi
public interface ProductDao {

	List<Product> queryProduct();

	List<Product> queryProductById(int productId);

	List<Product> queryProductByName(String name);

	int insertProduct(Product product);

	int updatedProduct(Product product);

	int deleteProduct(int productId);

	int queryCountProduct();

	List<Product> querySortByPrice();

	List<Product> querySortByPriceDesc();

}
