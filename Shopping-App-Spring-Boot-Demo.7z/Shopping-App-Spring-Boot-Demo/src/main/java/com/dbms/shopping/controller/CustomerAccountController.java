package com.dbms.shopping.controller;

import java.util.LinkedHashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

//Created by M Asim ALi
import com.alibaba.fastjson.JSON;
import com.dbms.shopping.entity.CustomerAccount;
import com.dbms.shopping.service.CustomerAccountService;

@RestController
@RequestMapping("/superadmin")
public class CustomerAccountController {
	@Autowired
	CustomerAccountService customerAccountService;

	@RequestMapping(value = "/register", method = RequestMethod.POST) // Register customer
	public String register(HttpServletRequest request) {
		String username = request.getParameter("username");
		String password = request.getParameter("pwd");
		String role = request.getParameter("role");
		LinkedHashMap<String, Object> result = new LinkedHashMap<>();

		if (role == "username" || role.equals("username")) {
			CustomerAccount customerAccount = new CustomerAccount();
			customerAccount.setUsername(username);
			customerAccount.setPassword(password);
			boolean user = customerAccountService.addCustomerAccount(customerAccount);
			if (user) {
				result.put("data", "success");
				result.put("msg", "register success");
				result.put("code", "200");
			}
		} else {
			result.put("code", "202");
		}
		String json = JSON.toJSON(result).toString();
		return json;
	}

}
