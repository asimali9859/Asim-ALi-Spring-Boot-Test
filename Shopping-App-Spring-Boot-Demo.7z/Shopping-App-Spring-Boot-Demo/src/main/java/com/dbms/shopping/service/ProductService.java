package com.dbms.shopping.service;

import java.util.List;

import com.dbms.shopping.entity.Product;

//Created by M Asim ALi
public interface ProductService {
	List<Product> getProductList();

	List<Product> getProductById(int productId);

	List<Product> getProductByName(String name);

	boolean addProduct(Product product);

	boolean modifyProduct(Product product);

	boolean deleteProduct(int productId);

	int countProduct();

	// by price increase
	List<Product> sortByProduct();

	// by price descendent
	List<Product> sortByProductDesc();

}
