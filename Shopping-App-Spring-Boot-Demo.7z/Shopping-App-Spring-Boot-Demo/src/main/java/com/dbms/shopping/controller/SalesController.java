package com.dbms.shopping.controller;

//Created by M Asim ALi
public class SalesController {
}
