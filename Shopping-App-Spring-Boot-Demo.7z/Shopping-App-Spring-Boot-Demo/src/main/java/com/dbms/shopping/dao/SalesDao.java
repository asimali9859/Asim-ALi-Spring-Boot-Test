package com.dbms.shopping.dao;

import java.util.List;

import com.dbms.shopping.entity.Sales;
//Created by M Asim ALi

public interface SalesDao {

	// login sales record
	List<Sales> searchSales(String username);

	// register sales record
	int insertSalesAccount(Sales salesAccount);

	// update sales record
	int updatedSalesAccount(Sales salesAccount);

	// Delete sales record
	int deleteSalesAccount(int empId);

}
