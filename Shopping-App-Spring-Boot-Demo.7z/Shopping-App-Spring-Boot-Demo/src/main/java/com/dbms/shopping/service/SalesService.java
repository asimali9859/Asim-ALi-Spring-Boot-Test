package com.dbms.shopping.service;

import java.util.List;

import com.dbms.shopping.entity.Sales;

//Created by M Asim ALi
public interface SalesService {

	boolean addSales(Sales sales);

	List<Sales> searchSales(String username);
}
