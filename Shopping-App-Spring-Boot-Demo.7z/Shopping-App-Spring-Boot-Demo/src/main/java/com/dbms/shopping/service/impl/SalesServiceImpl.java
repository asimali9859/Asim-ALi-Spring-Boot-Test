package com.dbms.shopping.service.impl;

import java.util.List;

//Created by M Asim ALi
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dbms.shopping.dao.SalesDao;
import com.dbms.shopping.entity.Sales;
import com.dbms.shopping.service.SalesService;

@Service
public class SalesServiceImpl implements SalesService {
	@Autowired
	SalesDao salesDao;

	@Transactional
	@Override
	public boolean addSales(Sales sales) {
		if (sales.getSaleId() != null) {
			try {
				int effectedNum = salesDao.insertSalesAccount(sales);
				if (effectedNum > 0) {
					return true;
				} else {
					throw new RuntimeException("Insert failed!");
				}
			} catch (Exception e) {
				throw new RuntimeException("Insert failed:" + e.getMessage());
			}

		} else {
			throw new RuntimeException("Insert data can not be null!!");
		}
	}

	@Override
	public List<Sales> searchSales(String username)// Search sale record with userName
	{
		return salesDao.searchSales(username);
	}

}