package com.dbms.shopping.dao;

import java.util.List;

import com.dbms.shopping.entity.CustomerAccount;

//Created by M Asim ALi
public interface CustomerAccountDao {
	int insertCustomerAccount(CustomerAccount customerAccount);

	List<CustomerAccount> searchCustomerAccount(String username);

	int queryCountCustomer();

}
