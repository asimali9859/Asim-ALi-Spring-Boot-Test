package com.dbms.shopping.entity;

//Created by M Asim ALi
public class Sales {
	// Primary Key
	private Integer saleId;

	private String saleDescription;

	public Integer getSaleId() {
		return saleId;
	}

	public void setSaleId(Integer saleId) {
		this.saleId = saleId;
	}

	public String getSaleDescription() {
		return saleDescription;
	}

	public void setSaleDescription(String saleDescription) {
		this.saleDescription = saleDescription;
	}

}
