package com.dbms.shopping.dao;

import java.util.List;

import com.dbms.shopping.entity.Customer;

//Created by M Asim ALi
public interface CustomerDao {
	List<Customer> queryCustomer();

	List<Customer> queryCustomerByName(String firstName);

	int insertCustomer(Customer customer);

	int queryCountCustomer();
}
